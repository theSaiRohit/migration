import React from 'react'

const DesAndPic = () => {
  return (
    <div className="des-pic-Card">
      <div>
        <h2><b>Unveiling List Rankings: Our Methodology</b></h2>
        <p>
          Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut
          fugit, sed quia consequuntur ma Nemo enim ipsam voluptatem quia
          voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur ma
          Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut
          fugit, sed quia consequuntur maNemo enim ipsam voluptatem quia
          voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur ma
          Headings Lorem spernatur aut odit Nemo enim ipsam voluptatem quia
          voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur ma
          Nemo enim ipsam voluptatem quia voluptas sit aspernatur.
        </p>
      </div>
      <div>
        <img src="https://via.placeholder.com/400x400" alt="" />
      </div>
    </div>
  );
}

export default DesAndPic